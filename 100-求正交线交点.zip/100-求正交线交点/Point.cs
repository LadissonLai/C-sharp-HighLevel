﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _100_求正交线交点
{
    class PointDraw
    {
        public float X { get; set; }
        public float Y { get; set; }
        public PointDraw(float x,float y)
        {
            this.X = x;
            this.Y = y;
        }
        public PointDraw()
        {

        }
    }
}
