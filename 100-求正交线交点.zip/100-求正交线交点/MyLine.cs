﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _100_求正交线交点
{

    class ZJXDataDefine
    {
        public int LineID { get; set; }
        public List<PointDraw> Points { get; set; }
    }
}
